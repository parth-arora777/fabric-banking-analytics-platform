CREATE TABLE [dbo].[bronze_transactions] (

	[step] varchar(8000) NULL, 
	[type] varchar(8000) NULL, 
	[amount] varchar(8000) NULL, 
	[nameOrig] varchar(8000) NULL, 
	[oldbalanceOrg] varchar(8000) NULL, 
	[newbalanceOrig] varchar(8000) NULL, 
	[nameDest] varchar(8000) NULL, 
	[oldbalanceDest] varchar(8000) NULL, 
	[newbalanceDest] varchar(8000) NULL, 
	[isFraud] varchar(8000) NULL, 
	[isFlaggedFraud] varchar(8000) NULL
);