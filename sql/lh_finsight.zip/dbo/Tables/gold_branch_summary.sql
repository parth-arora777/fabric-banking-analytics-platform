CREATE TABLE [dbo].[gold_branch_summary] (

	[region] varchar(8000) NULL, 
	[total_branches] bigint NULL, 
	[active_branches] bigint NULL, 
	[inactive_branches] bigint NULL, 
	[avg_staff_count] float NULL, 
	[max_staff_count] bigint NULL, 
	[min_staff_count] bigint NULL
);