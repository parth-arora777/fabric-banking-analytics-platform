CREATE TABLE [dbo].[gold_customer_summary] (

	[segment] varchar(8000) NULL, 
	[age_band] varchar(8000) NULL, 
	[customer_count] bigint NULL, 
	[avg_annual_income] float NULL, 
	[avg_credit_score] float NULL, 
	[active_customers] bigint NULL, 
	[inactive_customers] bigint NULL
);