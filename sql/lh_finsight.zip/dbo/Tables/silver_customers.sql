CREATE TABLE [dbo].[silver_customers] (

	[customer_id] varchar(8000) NULL, 
	[Full_Name] varchar(8000) NULL, 
	[email] varchar(8000) NULL, 
	[phone] varchar(8000) NULL, 
	[date_of_birth] date NULL, 
	[address_city] varchar(8000) NULL, 
	[address_country] varchar(8000) NULL, 
	[segment] varchar(8000) NULL, 
	[join_date] date NULL, 
	[credit_score] bigint NULL, 
	[annual_income] float NULL, 
	[is_active] varchar(8000) NULL, 
	[Age] bigint NULL, 
	[Age_Band] varchar(8000) NULL, 
	[Tenure] bigint NULL
);