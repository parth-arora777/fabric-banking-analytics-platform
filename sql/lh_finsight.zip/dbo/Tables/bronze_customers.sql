CREATE TABLE [dbo].[bronze_customers] (

	[customer_id] varchar(8000) NULL, 
	[first_name] varchar(8000) NULL, 
	[last_name] varchar(8000) NULL, 
	[email] varchar(8000) NULL, 
	[phone] varchar(8000) NULL, 
	[date_of_birth] varchar(8000) NULL, 
	[address_city] varchar(8000) NULL, 
	[address_country] varchar(8000) NULL, 
	[segment] varchar(8000) NULL, 
	[join_date] varchar(8000) NULL, 
	[credit_score] varchar(8000) NULL, 
	[annual_income] varchar(8000) NULL, 
	[is_active] varchar(8000) NULL
);