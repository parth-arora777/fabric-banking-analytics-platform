CREATE TABLE [dbo].[silver_products] (

	[product_id] varchar(8000) NULL, 
	[product_name] varchar(8000) NULL, 
	[category] varchar(8000) NULL, 
	[fee] bigint NULL, 
	[interest_rate] float NULL, 
	[fee band] varchar(8000) NULL
);