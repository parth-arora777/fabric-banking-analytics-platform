CREATE TABLE [dbo].[silver_branches] (

	[branch_id] varchar(8000) NULL, 
	[branch_name] varchar(8000) NULL, 
	[region] varchar(8000) NULL, 
	[country] varchar(8000) NULL, 
	[opened_date] date NULL, 
	[is_active] varchar(8000) NULL, 
	[staff_count] bigint NULL
);