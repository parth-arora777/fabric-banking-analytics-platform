CREATE TABLE [dbo].[bronze_products] (

	[product_id] varchar(8000) NULL, 
	[product_name] varchar(8000) NULL, 
	[category] varchar(8000) NULL, 
	[fee] varchar(8000) NULL, 
	[interest_rate] varchar(8000) NULL
);