CREATE TABLE [dbo].[bronze_validation_log] (

	[duplicates] bigint NULL, 
	[null_keys] bigint NULL, 
	[row_count] bigint NULL, 
	[status] varchar(8000) NULL, 
	[table] varchar(8000) NULL, 
	[validated_at] datetime2(6) NULL
);