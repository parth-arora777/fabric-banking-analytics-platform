CREATE TABLE [dbo].[gold_product_summary] (

	[category] varchar(8000) NULL, 
	[total_products] bigint NULL, 
	[avg_fee] float NULL, 
	[max_fee] bigint NULL, 
	[min_fee] bigint NULL, 
	[avg_interest_rate] float NULL, 
	[max_interest_rate] float NULL, 
	[min_interest_rate] float NULL
);