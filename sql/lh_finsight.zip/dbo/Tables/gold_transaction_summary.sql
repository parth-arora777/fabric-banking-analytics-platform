CREATE TABLE [dbo].[gold_transaction_summary] (

	[transaction_type] varchar(8000) NULL, 
	[transaction_year] int NULL, 
	[transaction_month] int NULL, 
	[transaction_count] bigint NULL, 
	[total_amount] float NULL, 
	[average_amount] float NULL, 
	[fraud_count] bigint NULL
);