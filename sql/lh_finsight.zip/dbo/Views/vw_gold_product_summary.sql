-- Auto Generated (Do not modify) E0F7CD98E0D0FF803660E3C1031FBB9C43EC8B4D20C4D2C4840C41CCBBE9A88E


CREATE   VIEW vw_gold_product_summary AS
SELECT *
FROM gold_product_summary;