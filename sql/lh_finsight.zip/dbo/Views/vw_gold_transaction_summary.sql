-- Auto Generated (Do not modify) F7A5C8831D3FE1ECD3B37613F71D5C67E05AFC3D20877FBAB3E07DB13407B8E0
CREATE   VIEW vw_gold_transaction_summary AS
SELECT *
FROM gold_transaction_summary;