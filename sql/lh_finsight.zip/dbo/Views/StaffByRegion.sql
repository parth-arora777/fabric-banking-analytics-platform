-- Auto Generated (Do not modify) 587CA90139B22A86002A453614F5D3D2C48A02077B1A63E156C06CA6819D155F

CREATE VIEW StaffByRegion as
SELECT region,SUM(staff_count) AS 'Total Staff'
FROM [dbo].[silver_branches] 
group by region