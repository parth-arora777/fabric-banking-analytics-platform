-- Auto Generated (Do not modify) 34886FE9B14FB477C1E652179EB009DB01A6FFD7929337EF9407D06A7130C00B


CREATE   VIEW vw_gold_branch_summary AS
SELECT *
FROM gold_branch_summary;