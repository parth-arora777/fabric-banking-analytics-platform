-- Auto Generated (Do not modify) A54A049D3CB0D35B2B3BC50972C96F39DA9EDE266F77F333B68F507BF3F046E5


CREATE   VIEW vw_gold_customer_summary AS
SELECT *
FROM gold_customer_summary;